﻿Public Class UserForm
    Private Sub UserForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ProjectDatabaseDataSet.CarTable' table. You can move, or remove it, as needed.
        Me.CarTableTableAdapter.Fill(Me.ProjectDatabaseDataSet.CarTable)

    End Sub

    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ProjectDatabaseDataSet = New TP_1_Team_11.ProjectDatabaseDataSet()
        Me.ProjectDatabaseDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.CarTableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CarTableTableAdapter = New TP_1_Team_11.ProjectDatabaseDataSetTableAdapters.CarTableTableAdapter()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CarNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CostDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MPGDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComfortDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UtilityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InteriorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.ProjectDatabaseDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProjectDatabaseDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CarTableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ProjectDatabaseDataSet
        '
        Me.ProjectDatabaseDataSet.DataSetName = "ProjectDatabaseDataSet"
        Me.ProjectDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ProjectDatabaseDataSetBindingSource
        '
        Me.ProjectDatabaseDataSetBindingSource.DataSource = Me.ProjectDatabaseDataSet
        Me.ProjectDatabaseDataSetBindingSource.Position = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.CarNameDataGridViewTextBoxColumn, Me.CostDataGridViewTextBoxColumn, Me.MPGDataGridViewTextBoxColumn, Me.ComfortDataGridViewTextBoxColumn, Me.UtilityDataGridViewTextBoxColumn, Me.InteriorDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.CarTableBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(156, 64)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(866, 174)
        Me.DataGridView1.TabIndex = 0
        '
        'CarTableBindingSource
        '
        Me.CarTableBindingSource.DataMember = "CarTable"
        Me.CarTableBindingSource.DataSource = Me.ProjectDatabaseDataSetBindingSource
        '
        'CarTableTableAdapter
        '
        Me.CarTableTableAdapter.ClearBeforeFill = True
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'CarNameDataGridViewTextBoxColumn
        '
        Me.CarNameDataGridViewTextBoxColumn.DataPropertyName = "Car Name"
        Me.CarNameDataGridViewTextBoxColumn.HeaderText = "Car Name"
        Me.CarNameDataGridViewTextBoxColumn.Name = "CarNameDataGridViewTextBoxColumn"
        '
        'CostDataGridViewTextBoxColumn
        '
        Me.CostDataGridViewTextBoxColumn.DataPropertyName = "Cost"
        Me.CostDataGridViewTextBoxColumn.HeaderText = "Cost"
        Me.CostDataGridViewTextBoxColumn.Name = "CostDataGridViewTextBoxColumn"
        '
        'MPGDataGridViewTextBoxColumn
        '
        Me.MPGDataGridViewTextBoxColumn.DataPropertyName = "MPG"
        Me.MPGDataGridViewTextBoxColumn.HeaderText = "MPG"
        Me.MPGDataGridViewTextBoxColumn.Name = "MPGDataGridViewTextBoxColumn"
        '
        'ComfortDataGridViewTextBoxColumn
        '
        Me.ComfortDataGridViewTextBoxColumn.DataPropertyName = "Comfort"
        Me.ComfortDataGridViewTextBoxColumn.HeaderText = "Comfort"
        Me.ComfortDataGridViewTextBoxColumn.Name = "ComfortDataGridViewTextBoxColumn"
        '
        'UtilityDataGridViewTextBoxColumn
        '
        Me.UtilityDataGridViewTextBoxColumn.DataPropertyName = "Utility"
        Me.UtilityDataGridViewTextBoxColumn.HeaderText = "Utility"
        Me.UtilityDataGridViewTextBoxColumn.Name = "UtilityDataGridViewTextBoxColumn"
        '
        'InteriorDataGridViewTextBoxColumn
        '
        Me.InteriorDataGridViewTextBoxColumn.DataPropertyName = "Interior"
        Me.InteriorDataGridViewTextBoxColumn.HeaderText = "Interior"
        Me.InteriorDataGridViewTextBoxColumn.Name = "InteriorDataGridViewTextBoxColumn"
        '
        'UserForm
        '
        Me.ClientSize = New System.Drawing.Size(1291, 506)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "UserForm"
        CType(Me.ProjectDatabaseDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProjectDatabaseDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CarTableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Private Sub UserForm_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ProjectDatabaseDataSet.CarTable' table. You can move, or remove it, as needed.
        Me.CarTableTableAdapter.Fill(Me.ProjectDatabaseDataSet.CarTable)

    End Sub
    Dim myObjectCreator As New ObjectCreator
        myObjectCreator.CreateObjectsAndLists()
End Class