﻿Public Class CarTable
    Public Shared Property CarTableList As New List(Of CarTable)
    Public Property ID As Long
    Public Property CarName As String
    Public Property Cost As Long
    Public Property MPG As Long
    Public Property Comfort As Long
    Public Property Utility As Long
    Public Property Interior As Long

    Public Sub New()


    End Sub
End Class
