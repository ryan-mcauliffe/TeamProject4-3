﻿
Imports System.Data.OleDb                             'Team11: We use the OleDB namespace for an MS Access namespace
'**************************************************************************************************************************
Public Class DBMS
    'ADO.NET Data Provider Objects
    Private rdbDataAdapter As New OleDbDataAdapter    'Team11: ADO.NET DataAdapter Object -  The DataAdapter facilitates the conversion from the external Database to the internal DataSet
    Private rdbConnection As New OleDbConnection      'Team11: ADO.NET Connection Object property -  
    Private rdbConnectionString As String             'Team11: ADO.NET Connection Object property -  The connection string is found in the app.config file.  This string points to the external DataBase
    Private rdbSQL As String                          'Team11: ADO.NET Command Object property - This string is declared for any SQL statements that we will write
    Private rdbDataSet As New DataSet                 'Team11: ADO.NET DataSet Object - The external Database will be transformed into an internal DataSetDim orderList As New List(Of SalesOrder)
    Private rdbCommand As New OleDbCommand            'Team11: ADO.NET DataSet Command Object - sql commands are conveyed via a Command object
    Private rdbTableName As String                    'Team11: sql Commands are executed on tables
    '**************************************************************************************************************************
    Public Sub New()
        ' This sub creates a new DBMSe object

    End Sub
    '**************************************************************************************************************************
    Public Sub RunSQL(ByVal rdbTableName, ByVal rdbSQL, ByVal rdbDataSet, ByVal rdbConnectionString)
        '
        'Team11:  First we build the Database Connection Object
        rdbConnection.ConnectionString = rdbConnectionString      'Team11:  We use the Connection String that is found in the app.config file to connect to the DataBase
        rdbCommand = rdbConnection.CreateCommand()
        '
        'Team11: Now we build the Command that will be sent to the Data Adapter
        rdbCommand.CommandText = rdbSQL                            'Team11: The sql is embedded in an object called a Command
        '
        'Team11: Now we build the Data Adapter
        rdbDataAdapter.SelectCommand = rdbCommand                  'Team11: The DataAdaptor executes the query Command
        rdbDataAdapter.Fill(rdbDataSet, rdbTableName)              'Team11: The Fill method of the DataAdaptor fills tables in the DataSet from data from the DataBase

    End Sub
End Class

